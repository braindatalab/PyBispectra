"""
============================
Compute time delay estimates
============================

This example demonstrates how time delay estimates (TDE) can be computed with
PyBispectra.
"""
